import { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { AnalysisSection } from './components/AnalysisSection';
import { Features } from './components/Features';
import { Footer } from './components/Footer';

export type Theme = 'dark' | 'light' | 'security';

export default function App() {
  const [theme, setTheme] = useState<Theme>('dark');

  const themeClasses = {
    dark: 'bg-gradient-to-br from-[#0a0a0a] to-[#1a1a1a] text-white',
    light: 'bg-gradient-to-br from-[#ffffff] to-[#f5f7fa] text-[#1a1a1a]',
    security: 'bg-gradient-to-br from-[#0a1628] to-[#162447] text-white relative'
  };

  return (
    <div className={`min-h-screen transition-all duration-300 ${themeClasses[theme]}`}>
      {/* Security Blue Mode Grid Pattern Overlay */}
      {theme === 'security' && (
        <div 
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        />
      )}
      
      <div className="relative z-10">
        <Header theme={theme} setTheme={setTheme} />
        <Hero theme={theme} />
        <AnalysisSection theme={theme} />
        <Features theme={theme} />
        <Footer theme={theme} />
      </div>
    </div>
  );
}
