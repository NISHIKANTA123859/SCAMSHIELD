import { Moon, Sun, Shield } from 'lucide-react';
import type { Theme } from '../App';

interface HeaderProps {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

export function Header({ theme, setTheme }: HeaderProps) {
  const buttonBaseClass = "p-3 rounded-full transition-all duration-300 cursor-pointer flex items-center justify-center";
  
  const getButtonClass = (buttonTheme: Theme) => {
    const isActive = theme === buttonTheme;
    
    if (buttonTheme === 'dark') {
      return `${buttonBaseClass} bg-[#2a2a2a] hover:scale-110 ${
        isActive ? 'ring-2 ring-[#00d4ff] shadow-lg shadow-[#00d4ff]/50' : ''
      }`;
    }
    if (buttonTheme === 'light') {
      return `${buttonBaseClass} bg-white text-[#1a1a1a] hover:scale-110 ${
        isActive ? 'ring-2 ring-[#0066cc] shadow-lg shadow-[#0066cc]/30' : ''
      }`;
    }
    return `${buttonBaseClass} bg-[#1e3a5f] hover:scale-110 ${
      isActive ? 'ring-2 ring-[#00ffff] shadow-lg shadow-[#00ffff]/50' : ''
    }`;
  };

  const textColor = theme === 'light' ? 'text-[#1a1a1a]' : 'text-white';
  const subtextColor = theme === 'light' ? 'text-[#4a4a4a]' : 'text-[#b8c5d6]';

  return (
    <header className="px-6 py-6 md:px-12">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <div>
          <div className="flex items-center gap-3">
            <span className="text-3xl">🛡️</span>
            <div>
              <h1 className={`text-2xl font-bold ${textColor}`}>ScamShield</h1>
              <p className={`text-sm ${subtextColor}`}>Scam Awareness & Detection Platform</p>
            </div>
          </div>
        </div>

        {/* Theme Toggle Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setTheme('dark')}
            className={getButtonClass('dark')}
            aria-label="Dark Mode"
            title="Dark Mode"
          >
            <Moon className="w-5 h-5 text-white" />
          </button>
          
          <button
            onClick={() => setTheme('light')}
            className={getButtonClass('light')}
            aria-label="Light Mode"
            title="Light Mode"
          >
            <Sun className="w-5 h-5" />
          </button>
          
          <button
            onClick={() => setTheme('security')}
            className={getButtonClass('security')}
            aria-label="Security Blue Mode"
            title="Security Blue Mode"
          >
            <Shield className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </header>
  );
}
