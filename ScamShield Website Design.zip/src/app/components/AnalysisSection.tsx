import { useState } from 'react';
import { AlertCircle, CheckCircle, AlertTriangle, Loader2 } from 'lucide-react';
import type { Theme } from '../App';

interface AnalysisSectionProps {
  theme: Theme;
}

type RiskLevel = 'safe' | 'suspicious' | 'high' | null;

interface AnalysisResult {
  riskLevel: RiskLevel;
  message: string;
  details: string[];
  recommendations: string[];
}

export function AnalysisSection({ theme }: AnalysisSectionProps) {
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const cardColors = {
    dark: 'bg-[#2a2a2a] shadow-xl',
    light: 'bg-white shadow-lg',
    security: 'bg-[#1e3a5f] shadow-2xl shadow-[#00ffff]/20'
  };

  const inputColors = {
    dark: 'bg-[#1a1a1a] border-[#3a3a3a] text-white placeholder-gray-500 focus:border-[#00d4ff]',
    light: 'bg-[#f5f7fa] border-[#e0e0e0] text-[#1a1a1a] placeholder-gray-400 focus:border-[#0066cc]',
    security: 'bg-[#0a1628] border-[#2a4a6f] text-white placeholder-[#6a8ab0] focus:border-[#00ffff]'
  };

  const buttonColors = {
    dark: 'bg-[#00d4ff] hover:shadow-lg hover:shadow-[#00d4ff]/50 text-black',
    light: 'bg-[#0066cc] hover:shadow-lg hover:shadow-[#0066cc]/30 text-white',
    security: 'bg-[#00ffff] hover:shadow-2xl hover:shadow-[#00ffff]/60 text-black'
  };

  const textColor = theme === 'light' ? 'text-[#1a1a1a]' : 'text-white';
  const subtextColor = theme === 'light' ? 'text-[#4a4a4a]' : 'text-[#b8c5d6]';

  const analyzeText = () => {
    if (!inputText.trim()) return;

    setIsAnalyzing(true);
    setResult(null);

    // Simulate analysis with realistic detection
    setTimeout(() => {
      const text = inputText.toLowerCase();
      let riskLevel: RiskLevel = 'safe';
      const details: string[] = [];
      const recommendations: string[] = [];

      // Check for high-risk indicators
      const highRiskPatterns = [
        'urgent action required',
        'verify your account',
        'suspend',
        'click here immediately',
        'confirm your identity',
        'unusual activity',
        'prize',
        'lottery',
        'inheritance',
        'nigerian prince',
        'bitcoin',
        'crypto',
        'investment opportunity'
      ];

      const suspiciousPatterns = [
        'limited time',
        'act now',
        'click here',
        'verify',
        'update payment',
        'confirm',
        'security alert',
        'account',
        'password'
      ];

      // Check for URLs
      const urlPattern = /(https?:\/\/[^\s]+)/g;
      const urls = text.match(urlPattern);
      
      if (urls) {
        details.push(`🔗 Contains ${urls.length} link(s): ${urls.join(', ')}`);
        
        // Check for suspicious domains
        const suspiciousDomains = urls.some(url => 
          !url.includes('.com') && !url.includes('.org') && !url.includes('.edu') ||
          url.includes('bit.ly') || url.includes('tinyurl')
        );
        
        if (suspiciousDomains) {
          riskLevel = 'suspicious';
          details.push('⚠️ Suspicious or shortened URLs detected');
        }
      }

      // Check for high-risk keywords
      const foundHighRisk = highRiskPatterns.filter(pattern => text.includes(pattern));
      if (foundHighRisk.length > 0) {
        riskLevel = 'high';
        details.push(`🚨 High-risk keywords detected: ${foundHighRisk.join(', ')}`);
      }

      // Check for suspicious keywords
      const foundSuspicious = suspiciousPatterns.filter(pattern => text.includes(pattern));
      if (foundSuspicious.length > 0 && riskLevel === 'safe') {
        riskLevel = 'suspicious';
        details.push(`⚠️ Suspicious patterns detected: ${foundSuspicious.join(', ')}`);
      }

      // Check for urgency
      if (text.includes('urgent') || text.includes('immediately') || text.includes('now')) {
        if (riskLevel === 'safe') riskLevel = 'suspicious';
        details.push('⏰ Creates false sense of urgency');
      }

      // Check for personal information requests
      if (text.includes('ssn') || text.includes('social security') || text.includes('password') || text.includes('pin')) {
        riskLevel = 'high';
        details.push('🔐 Requests sensitive personal information');
      }

      // Generate recommendations based on risk level
      if (riskLevel === 'high') {
        recommendations.push('❌ DO NOT click any links or respond to this message');
        recommendations.push('🗑️ Delete this message immediately');
        recommendations.push('📞 Contact the organization directly using official channels');
        recommendations.push('🚨 Report this as phishing/scam to authorities');
      } else if (riskLevel === 'suspicious') {
        recommendations.push('🔍 Verify sender identity through official channels');
        recommendations.push('⚠️ Do not click links without verification');
        recommendations.push('📧 Check sender email address carefully');
        recommendations.push('🤔 Be cautious and trust your instincts');
      } else {
        recommendations.push('✅ Message appears safe, but always stay vigilant');
        recommendations.push('🔍 Verify sender if unexpected');
        recommendations.push('🛡️ Never share sensitive information via messages');
      }

      if (details.length === 0) {
        details.push('✓ No obvious scam indicators detected');
      }

      setResult({
        riskLevel,
        message: riskLevel === 'high' 
          ? 'HIGH RISK - Likely Scam Detected' 
          : riskLevel === 'suspicious'
          ? 'SUSPICIOUS - Exercise Caution'
          : 'APPEARS SAFE - Stay Vigilant',
        details,
        recommendations
      });

      setIsAnalyzing(false);
    }, 1500);
  };

  const getRiskIcon = (risk: RiskLevel) => {
    if (risk === 'high') return <AlertCircle className="w-8 h-8 text-red-500" />;
    if (risk === 'suspicious') return <AlertTriangle className="w-8 h-8 text-orange-500" />;
    return <CheckCircle className="w-8 h-8 text-green-500" />;
  };

  const getRiskBadge = (risk: RiskLevel) => {
    if (risk === 'high') return '🔴 High Risk';
    if (risk === 'suspicious') return '🟠 Suspicious';
    return '🟢 Safe';
  };

  return (
    <section id="analysis-section" className="px-6 py-16 md:px-12">
      <div className="max-w-4xl mx-auto">
        <h3 className={`text-4xl font-bold mb-8 text-center ${textColor}`}>
          Analyze Suspicious Content
        </h3>

        {/* Input Card */}
        <div className={`${cardColors[theme]} rounded-2xl p-8 mb-8 transition-all duration-300`}>
          <label className={`block mb-4 text-lg font-semibold ${textColor}`}>
            Paste the suspicious message, email, or link below:
          </label>
          
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Example: 'URGENT! Your account will be suspended. Click here to verify immediately...'"
            className={`w-full h-48 p-4 rounded-xl border-2 transition-all duration-200 resize-none ${inputColors[theme]}`}
          />

          <button
            onClick={analyzeText}
            disabled={!inputText.trim() || isAnalyzing}
            className={`${buttonColors[theme]} w-full mt-6 py-4 rounded-xl font-bold text-lg transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-2`}
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                Analyzing...
              </>
            ) : (
              'Analyze Now'
            )}
          </button>
        </div>

        {/* Results Card */}
        {result && (
          <div className={`${cardColors[theme]} rounded-2xl p-8 animate-in fade-in duration-500`}>
            <div className="flex items-start gap-4 mb-6">
              {getRiskIcon(result.riskLevel)}
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-2xl font-bold">{getRiskBadge(result.riskLevel)}</span>
                </div>
                <h4 className={`text-2xl font-bold ${textColor}`}>{result.message}</h4>
              </div>
            </div>

            {/* Analysis Details */}
            <div className="mb-6">
              <h5 className={`text-lg font-semibold mb-3 ${textColor}`}>Analysis Details:</h5>
              <div className={`${theme === 'light' ? 'bg-[#f5f7fa]' : theme === 'security' ? 'bg-[#0a1628]' : 'bg-[#1a1a1a]'} rounded-lg p-4 space-y-2`}>
                {result.details.map((detail, index) => (
                  <div key={index} className={`${subtextColor} font-mono text-sm`}>
                    {detail}
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div>
              <h5 className={`text-lg font-semibold mb-3 ${textColor}`}>Safety Recommendations:</h5>
              <ul className="space-y-2">
                {result.recommendations.map((rec, index) => (
                  <li key={index} className={`${subtextColor} flex items-start gap-2`}>
                    <span className="mt-1">•</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
