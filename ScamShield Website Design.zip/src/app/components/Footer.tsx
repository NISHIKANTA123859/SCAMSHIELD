import { Github, Twitter, Linkedin, Mail } from 'lucide-react';
import type { Theme } from '../App';

interface FooterProps {
  theme: Theme;
}

export function Footer({ theme }: FooterProps) {
  const borderColor = {
    dark: 'border-[#2a2a2a]',
    light: 'border-[#e0e0e0]',
    security: 'border-[#1e3a5f]'
  };

  const textColor = theme === 'light' ? 'text-[#1a1a1a]' : 'text-white';
  const subtextColor = theme === 'light' ? 'text-[#4a4a4a]' : 'text-[#b8c5d6]';
  
  const iconHoverColor = {
    dark: 'hover:text-[#00d4ff]',
    light: 'hover:text-[#0066cc]',
    security: 'hover:text-[#00ffff]'
  };

  return (
    <footer className={`px-6 py-12 md:px-12 border-t ${borderColor[theme]}`}>
      <div className="max-w-7xl mx-auto">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl">🛡️</span>
              <span className={`text-xl font-bold ${textColor}`}>ScamShield</span>
            </div>
            <p className={subtextColor}>
              Protecting users from online scams with advanced AI detection.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className={`font-bold mb-4 ${textColor}`}>Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Home
                </a>
              </li>
              <li>
                <a href="#analysis-section" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Analyze
                </a>
              </li>
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  About
                </a>
              </li>
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Resources
                </a>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className={`font-bold mb-4 ${textColor}`}>Resources</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Scam Database
                </a>
              </li>
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Safety Tips
                </a>
              </li>
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Report Scam
                </a>
              </li>
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Help Center
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className={`font-bold mb-4 ${textColor}`}>Legal</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Cookie Policy
                </a>
              </li>
              <li>
                <a href="#" className={`${subtextColor} ${iconHoverColor[theme]} transition-colors`}>
                  Disclaimer
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Social Links */}
        <div className={`flex items-center justify-center gap-6 py-6 border-t ${borderColor[theme]}`}>
          <a
            href="#"
            className={`${subtextColor} ${iconHoverColor[theme]} transition-all duration-300 hover:scale-110`}
            aria-label="GitHub"
          >
            <Github className="w-6 h-6" />
          </a>
          <a
            href="#"
            className={`${subtextColor} ${iconHoverColor[theme]} transition-all duration-300 hover:scale-110`}
            aria-label="Twitter"
          >
            <Twitter className="w-6 h-6" />
          </a>
          <a
            href="#"
            className={`${subtextColor} ${iconHoverColor[theme]} transition-all duration-300 hover:scale-110`}
            aria-label="LinkedIn"
          >
            <Linkedin className="w-6 h-6" />
          </a>
          <a
            href="#"
            className={`${subtextColor} ${iconHoverColor[theme]} transition-all duration-300 hover:scale-110`}
            aria-label="Email"
          >
            <Mail className="w-6 h-6" />
          </a>
        </div>

        {/* Bottom Bar */}
        <div className={`text-center pt-6 border-t ${borderColor[theme]}`}>
          <p className={subtextColor}>
            © 2026 ScamShield • <span className="font-semibold">UNSEEN / UNSPOKEN Challenge</span>
          </p>
          <p className={`${subtextColor} text-sm mt-2`}>
            Stay safe, stay informed, stay protected
          </p>
        </div>
      </div>
    </footer>
  );
}
