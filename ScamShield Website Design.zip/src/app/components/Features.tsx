import { MessageSquare, Link2, Shield, Lightbulb } from 'lucide-react';
import type { Theme } from '../App';

interface FeaturesProps {
  theme: Theme;
}

export function Features({ theme }: FeaturesProps) {
  const cardColors = {
    dark: 'bg-[#2a2a2a] shadow-xl hover:shadow-2xl',
    light: 'bg-white shadow-lg hover:shadow-xl',
    security: 'bg-[#1e3a5f] shadow-2xl shadow-[#00ffff]/10 hover:shadow-[#00ffff]/30'
  };

  const iconColors = {
    dark: 'text-[#00d4ff]',
    light: 'text-[#0066cc]',
    security: 'text-[#00ffff]'
  };

  const textColor = theme === 'light' ? 'text-[#1a1a1a]' : 'text-white';
  const subtextColor = theme === 'light' ? 'text-[#4a4a4a]' : 'text-[#b8c5d6]';

  const features = [
    {
      icon: MessageSquare,
      title: 'Message Detection',
      description: 'Advanced AI analyzes text messages, emails, and social media messages for scam patterns and suspicious content.'
    },
    {
      icon: Link2,
      title: 'Link Analysis',
      description: 'Automatically scans URLs for phishing attempts, malicious domains, and suspicious redirects before you click.'
    },
    {
      icon: Shield,
      title: 'Risk Classification',
      description: 'Clear risk levels (Safe, Suspicious, High Risk) with detailed explanations and confidence scores.'
    },
    {
      icon: Lightbulb,
      title: 'Safety Tips',
      description: 'Personalized recommendations and actionable steps to protect yourself from specific threats.'
    }
  ];

  return (
    <section className="px-6 py-16 md:px-12">
      <div className="max-w-7xl mx-auto">
        <h3 className={`text-4xl font-bold mb-4 text-center ${textColor}`}>
          Powerful Protection Features
        </h3>
        <p className={`text-xl text-center mb-12 ${subtextColor} max-w-2xl mx-auto`}>
          Our advanced detection system uses multiple layers of analysis to keep you safe
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className={`${cardColors[theme]} rounded-2xl p-6 transition-all duration-300 hover:scale-105 transform`}
              >
                <div className={`${iconColors[theme]} mb-4`}>
                  <Icon className="w-12 h-12" />
                </div>
                <h4 className={`text-xl font-bold mb-3 ${textColor}`}>
                  {feature.title}
                </h4>
                <p className={subtextColor}>
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Stats Section */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <div>
            <div className={`text-5xl font-bold mb-2 ${iconColors[theme]}`}>99.8%</div>
            <div className={subtextColor}>Detection Accuracy</div>
          </div>
          <div>
            <div className={`text-5xl font-bold mb-2 ${iconColors[theme]}`}>1M+</div>
            <div className={subtextColor}>Scams Analyzed</div>
          </div>
          <div>
            <div className={`text-5xl font-bold mb-2 ${iconColors[theme]}`}>24/7</div>
            <div className={subtextColor}>Always Available</div>
          </div>
        </div>
      </div>
    </section>
  );
}
