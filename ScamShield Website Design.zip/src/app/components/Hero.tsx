import type { Theme } from '../App';

interface HeroProps {
  theme: Theme;
}

export function Hero({ theme }: HeroProps) {
  const accentColors = {
    dark: 'text-[#00d4ff]',
    light: 'text-[#0066cc]',
    security: 'text-[#00ffff]'
  };

  const buttonColors = {
    dark: 'bg-[#00d4ff] hover:shadow-lg hover:shadow-[#00d4ff]/50 text-black',
    light: 'bg-[#0066cc] hover:shadow-lg hover:shadow-[#0066cc]/30 text-white',
    security: 'bg-[#00ffff] hover:shadow-2xl hover:shadow-[#00ffff]/60 text-black'
  };

  const textColor = theme === 'light' ? 'text-[#1a1a1a]' : 'text-white';
  const subtextColor = theme === 'light' ? 'text-[#4a4a4a]' : 'text-[#e0e0e0]';

  const scrollToAnalysis = () => {
    document.getElementById('analysis-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="px-6 py-20 md:px-12">
      <div className="max-w-5xl mx-auto text-center">
        <h2 className={`text-5xl md:text-7xl font-bold mb-6 ${textColor}`}>
          Protect Yourself from{' '}
          <span className={accentColors[theme]}>Online Scams</span>
        </h2>
        
        <p className={`text-xl md:text-2xl mb-12 ${subtextColor} max-w-3xl mx-auto`}>
          Instantly analyze suspicious messages and links with our advanced detection system
        </p>

        <button
          onClick={scrollToAnalysis}
          className={`${buttonColors[theme]} px-10 py-4 rounded-full font-semibold text-lg transition-all duration-300 hover:scale-105 transform`}
        >
          Start Analysis
        </button>

        {/* Decorative Elements */}
        <div className="mt-16 flex justify-center gap-8 flex-wrap">
          <div className={`flex items-center gap-2 ${subtextColor}`}>
            <div className={`w-3 h-3 rounded-full ${theme === 'security' ? 'bg-[#00ffff]' : theme === 'light' ? 'bg-[#0066cc]' : 'bg-[#00d4ff]'} animate-pulse`}></div>
            <span>Real-time Detection</span>
          </div>
          <div className={`flex items-center gap-2 ${subtextColor}`}>
            <div className={`w-3 h-3 rounded-full ${theme === 'security' ? 'bg-[#00ffff]' : theme === 'light' ? 'bg-[#0066cc]' : 'bg-[#00d4ff]'} animate-pulse`}></div>
            <span>AI-Powered Analysis</span>
          </div>
          <div className={`flex items-center gap-2 ${subtextColor}`}>
            <div className={`w-3 h-3 rounded-full ${theme === 'security' ? 'bg-[#00ffff]' : theme === 'light' ? 'bg-[#0066cc]' : 'bg-[#00d4ff]'} animate-pulse`}></div>
            <span>Free & Anonymous</span>
          </div>
        </div>
      </div>
    </section>
  );
}
